Please check the original source code preserved in original_library_source for details of the licensing of this package.
