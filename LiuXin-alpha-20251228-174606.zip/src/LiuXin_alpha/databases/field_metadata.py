import traceback
from collections import OrderedDict

from six import iterkeys
from six import itervalues
from six import iteritems

from LiuXin.utils.calibre.tweaks import tweaks
from LiuXin.utils.icu import lower as icu_lower
from LiuXin.utils.localization import _


# Todo: This should not be needed anymore
def calibre_name_to_liuxin_name(table_name):
    """
    Take the name of a calibre table and return the LiuXin equivalent table.
    :param table_name:
    :return:
    """
    # Translation between the calibre and LiuXin names
    if table_name == "publisher":
        return "publishers"
    if table_name == "rating":
        return "ratings"
    if table_name == "comment":
        return "comments"
    if table_name == "cover":
        return "covers"
    if table_name == "genre":
        return "genres"

    return table_name


# Todo: We've currently got stuff like the fields to declare and use in multiple different places - need to make that
#       dryer - should only declare and act on the field names here.
# Todo: the field is being seperately noted as custom elsewhere - when it's actually in the metadata - fix
# Todo: Implement and test a last modified field for all tables in the database
# Todo: "in_table" and "main_table" have become degenerate - need to remove them
def _builtin_field_metadata():
    """
    This is a function so that changing the UI language allows newly created field metadata objects to have correctly
    translated labels for builtin fields.
    Contains information needed to read from the various tables.
    Note: If table is None then the data will be read from the Meta view.
    :return:
    """
    return [
        (
            "authors",
            {
                "table": "authors",
                "column": "author",
                "link_column": "author",
                "category_sort": "sort",
                "datatype": "text",
                "is_multiple": {
                    "cache_to_list": ",",
                    "ui_to_list": "&",
                    "list_to_ui": " & ",
                },
                "kind": "field",
                "name": _("Authors"),
                "search_terms": ["authors", "author"],
                "is_custom": False,
                "is_category": True,
                "is_csp": False,
                "main_table": "titles",
                "auxiliary_table": "creators",
            },
        ),
        (
            "languages",
            {
                "table": "languages",
                "column": "language_code",
                "link_column": "lang_code",
                "category_sort": "language_code",
                "datatype": "text",
                "is_multiple": {
                    "cache_to_list": ",",
                    "ui_to_list": ",",
                    "list_to_ui": ", ",
                },
                "kind": "field",
                "name": _("Languages"),
                "search_terms": ["languages", "language"],
                "is_custom": False,
                "is_category": True,
                "is_csp": False,
                "main_table": "titles",
                "auxiliary_table": "languages",
            },
        ),
        (
            "series",
            {
                "table": "series",
                "table_id": "series_id",
                "column": "series",
                "link_column": "series",
                "category_sort": "(title_sort(name))",
                "datatype": "series",
                "is_multiple": {},
                "kind": "field",
                "name": _("Series"),
                "search_terms": ["series"],
                "link_attrs": [
                    "index",
                ],
                "is_custom": False,
                "is_category": True,
                "is_csp": False,
                "main_table": "titles",
                "auxiliary_table": "series",
            },
        ),
        (
            "genre",
            {
                "table": "genres",
                "table_id": "genre_id",
                "column": "genre",
                "link_column": "genres",
                "category_sort": "(title_sort(name))",
                "datatype": "text",
                "is_multiple": {},
                "kind": "field",
                "name": _("Genre"),
                "search_terms": ["genre"],
                "is_custom": False,
                "is_category": True,
                "is_csp": False,
                "main_table": "titles",
                "auxiliary_table": "genres",
            },
        ),
        (
            "subjects",
            {
                "table": "subjects",
                "table_id": "subject_id",
                "column": "subject",
                "link_column": "subjects",
                "category_sort": "(title_sort(name))",
                "datatype": "text",
                "is_multiple": {},
                "kind": "field",
                "name": _("Subject"),
                "search_terms": ["subject"],
                "is_custom": False,
                "is_category": True,
                "is_csp": False,
                "main_table": "titles",
                "auxiliary_table": "subjects",
            },
        ),
        (
            "synopses",
            {
                "table": "synopses",
                "table_id": "synopsis_id",
                "column": "synopsis",
                "link_column": "synopses",
                "category_sort": "(title_sort(name))",
                "datatype": "text",
                "is_multiple": {},
                "kind": "field",
                "name": _("Synopsis"),
                "search_terms": ["synopsis"],
                "is_custom": False,
                "is_category": True,
                "is_csp": False,
                "main_table": "titles",
                "auxiliary_table": "synopses",
            },
        ),
        (
            "notes",
            {
                "table": "notes",
                "table_id": "note_id",
                "column": "note",
                "link_column": "notes",
                "category_sort": "(title_sort(name))",
                "datatype": "text",
                "is_multiple": {},
                "kind": "field",
                "name": _("Note"),
                "search_terms": ["note"],
                "is_custom": False,
                "is_category": True,
                "is_csp": False,
                "main_table": "titles",
                "auxiliary_table": "notes",
                "val_unique": False,
            },
        ),
        (
            "formats",
            {
                "table": None,
                "column": None,
                "datatype": "text",
                "is_multiple": {
                    "cache_to_list": ",",
                    "ui_to_list": ",",
                    "list_to_ui": ", ",
                },
                "kind": "field",
                "name": _("Formats"),
                "search_terms": ["formats", "format"],
                "is_custom": False,
                "is_category": True,
                "is_csp": False,
                "main_table": "books",
                "auxiliary_table": "formats",
            },
        ),
        (
            "covers",
            {
                "table": None,
                "column": "has_cover",
                "datatype": "text",
                "is_multiple": {
                    "cache_to_list": ",",
                    "ui_to_list": ",",
                    "list_to_ui": ", ",
                },
                "kind": "field",
                "name": _("Covers"),
                "search_terms": ["covers"],
                "is_custom": False,
                "is_category": False,
                "is_csp": False,
                "main_table": "books",
                "auxiliary_table": "covers",
            },
        ),
        (
            "publisher",
            {
                "table": "publishers",
                "table_id": "publisher_id",
                "column": "publisher",
                "link_column": "publisher",
                "category_sort": "publisher",
                "datatype": "text",
                "is_multiple": {},
                "kind": "field",
                "name": _("Publisher"),
                "search_terms": ["publisher"],
                "is_custom": False,
                "is_category": True,
                "is_csp": False,
                "main_table": "titles",
                "auxiliary_table": "publishers",
            },
        ),
        (
            "rating",
            {
                "table": "ratings",
                "column": "rating",
                "link_column": "rating",
                "category_sort": "rating",
                "datatype": "rating",
                "is_multiple": {},
                "kind": "field",
                "name": _("Rating"),
                "search_terms": ["rating"],
                "is_custom": False,
                "is_category": True,
                "is_csp": False,
                "main_table": "titles",
                "auxiliary_table": "ratings",
            },
        ),
        # Todo: Not sure if actually in use
        (
            "news",
            {
                "table": "news",
                "column": "name",
                "category_sort": "name",
                "datatype": None,
                "is_multiple": {},
                "kind": "category",
                "name": _("News"),
                "search_terms": [],
                "is_custom": False,
                "is_category": True,
                "is_csp": False,
                "main_table": "titles",
                "auxiliary_table": "news",
            },
        ),
        (
            "tags",
            {
                "table": "tags",
                "column": "tag",
                "link_column": "tag",
                "category_sort": "name",
                "datatype": "text",
                "is_multiple": {
                    "cache_to_list": ",",
                    "ui_to_list": ",",
                    "list_to_ui": ", ",
                },
                "kind": "field",
                "name": _("Tags"),
                "search_terms": ["tags", "tag"],
                "is_custom": False,
                "is_category": True,
                "is_csp": False,
                "main_table": "titles",
                "auxiliary_table": "tags",
            },
        ),
        # Todo: Automatically extend search_terms with all the identifiers known to constants
        (
            "identifiers",
            {
                "table": None,
                "column": None,
                "datatype": "text",
                "is_multiple": {
                    "cache_to_list": ",",
                    "ui_to_list": ",",
                    "list_to_ui": ", ",
                },
                "kind": "field",
                "name": _("Identifiers"),
                "search_terms": ["identifiers", "identifier", "isbn"],
                "is_custom": False,
                "is_category": True,
                "is_csp": True,
                "main_table": "titles",
                "auxiliary_table": "identifiers",
            },
        ),
        (
            "author_sort",
            {
                "table": None,
                "column": "author_sort",
                "datatype": "text",
                "is_multiple": {},
                "kind": "field",
                "name": _("Author Sort"),
                "search_terms": ["author_sort"],
                "is_custom": False,
                "is_category": False,
                "is_csp": False,
                "in_table": "books",
                "liuxin_table_name": "title_creator_sort",
                "main_table": "titles",
                "auxiliary_table": "titles",
            },
        ),
        (
            "au_map",
            {
                "table": None,
                "column": None,
                "datatype": "text",
                "is_multiple": {
                    "cache_to_list": ",",
                    "ui_to_list": None,
                    "list_to_ui": None,
                },
                "kind": "field",
                "name": None,
                "search_terms": [],
                "is_custom": False,
                "is_category": False,
                "is_csp": False,
            },
        ),
        (
            "comments",
            {
                "table": "comments",
                "column": "comment",
                "datatype": "text",
                "is_multiple": {},
                "kind": "field",
                "name": _("Comments"),
                "search_terms": ["comments", "comment"],
                "is_custom": False,
                "is_category": False,
                "is_csp": False,
                "main_table": "titles",
                "auxiliary_table": "comments",
            },
        ),
        (
            "cover",
            {
                "table": None,
                "column": None,
                "datatype": "int",
                "is_multiple": {},
                "kind": "field",
                "name": _("Cover"),
                "search_terms": ["cover"],
                "is_custom": False,
                "is_category": False,
                "is_csp": False,
                "in_table": "books",
                "main_table": "books",
                "auxiliary_table": "covers",
            },
        ),
        (
            "id",
            {
                "table": None,
                "column": None,
                "datatype": "int",
                "is_multiple": {},
                "kind": "field",
                "name": None,
                "search_terms": ["id"],
                "is_custom": False,
                "is_category": False,
                "is_csp": False,
                "in_table": "titles",
                "main_table": "titles",
                "auxiliary_table": "titles",
            },
        ),
        (
            "last_modified",
            {
                "table": None,
                "column": None,
                "datatype": "datetime",
                "is_multiple": {},
                "kind": "field",
                "name": _("Modified"),
                "search_terms": ["last_modified"],
                "is_custom": False,
                "is_category": False,
                "is_csp": False,
                "main_table": "titles",
                "auxiliary_table": "titles",
            },
        ),
        (
            "ondevice",
            {
                "table": None,
                "column": None,
                "datatype": "text",
                "is_multiple": {},
                "kind": "field",
                "name": _("On Device"),
                "search_terms": ["ondevice"],
                "is_custom": False,
                "is_category": False,
                "is_csp": False,
                "main_table": "virtual",
                "auxiliary_table": "virtual",
            },
        ),
        (
            "path",
            {
                "table": None,
                "column": None,
                "datatype": "text",
                "is_multiple": {},
                "kind": "field",
                "name": _("Path"),
                "search_terms": [],
                "is_custom": False,
                "is_category": False,
                "is_csp": False,
                "main_table": "books",
                "auxiliary_table": "books",
            },
        ),
        (
            "pubdate",
            {
                "table": None,
                "column": None,
                "datatype": "datetime",
                "is_multiple": {},
                "kind": "field",
                "name": _("Published"),
                "search_terms": ["pubdate"],
                "is_custom": False,
                "is_category": False,
                "is_csp": False,
                "main_table": "titles",
                "auxiliary_table": "titles",
            },
        ),
        (
            "marked",
            {
                "table": None,
                "column": None,
                "datatype": "text",
                "is_multiple": {},
                "kind": "field",
                "name": None,
                "search_terms": ["marked"],
                "is_custom": False,
                "is_category": False,
                "is_csp": False,
                "main_table": "virtual",
                "auxiliary_table": "virtual",
            },
        ),
        # Todo: Not sure 'in_table' for this method actually makes good sense
        (
            "series_index",
            {
                "table": None,
                "column": None,
                "datatype": "float",
                "is_multiple": {},
                "kind": "field",
                "name": None,
                "search_terms": ["series_index"],
                "is_custom": False,
                "is_category": False,
                "is_csp": False,
                "in_table": "series_title_links",
                "main_table": "titles",
                "auxiliary_table": "series",
            },
        ),
        (
            "series_sort",
            {
                "table": None,
                "column": None,
                "datatype": "text",
                "is_multiple": {},
                "kind": "field",
                "name": _("Series Sort"),
                "search_terms": ["series_sort"],
                "is_custom": False,
                "is_category": False,
                "is_csp": False,
                "main_table": "titles",
                "auxiliary_table": "titles",
            },
        ),
        (
            "sort",
            {
                "table": None,
                "column": None,
                "datatype": "text",
                "is_multiple": {},
                "kind": "field",
                "name": _("Title Sort"),
                "search_terms": ["title_sort"],
                "is_custom": False,
                "is_category": False,
                "is_csp": False,
                "in_table": "titles",
                "main_table": "titles",
                "auxiliary_table": "titles",
            },
        ),
        (
            "size",
            {
                "table": None,
                "column": None,
                "datatype": "float",
                "is_multiple": {},
                "kind": "field",
                "name": _("Size"),
                "search_terms": ["size"],
                "is_custom": False,
                "is_category": False,
                "is_csp": False,
                "main_table": "meta",
                "auxiliary_table": "meta",
            },
        ),
        (
            "timestamp",
            {
                "table": None,
                "column": "datestamp",
                "datatype": "datetime",
                "is_multiple": {},
                "kind": "field",
                "name": _("Date"),
                "search_terms": ["date"],
                "is_custom": False,
                "is_category": False,
                "is_csp": False,
                "liuxin_table_name": "title_datestamp",
                "main_table": "titles",
                "auxiliary_table": "titles",
            },
        ),
        (
            "title",
            {
                "table": None,
                "column": "title",
                "datatype": "text",
                "is_multiple": {},
                "kind": "field",
                "name": _("Title"),
                "search_terms": ["title"],
                "is_custom": False,
                "is_category": False,
                "is_csp": False,
                "in_table": "titles",
                "main_table": "titles",
                "auxiliary_table": "titles",
            },
        ),
        (
            "uuid",
            {
                "table": None,
                "column": "uuid",
                "datatype": "text",
                "is_multiple": {},
                "kind": "field",
                "name": None,
                "search_terms": ["uuid"],
                "is_custom": False,
                "is_category": False,
                "is_csp": False,
                "in_table": "books",
                "main_table": "books",
                "auxiliary_table": "books",
            },
        ),
    ]


# }}}


class FieldMetadata(dict):
    """
    key: the key to the dictionary is:
    - for standard fields, the metadata field name.
    - for custom fields, the metadata field name prefixed by '#'
    This is done to create two 'namespaces' so the names don't clash

    label: the actual column label. No prefixing.

    datatype: the type of information in the field. Valid values are listed in
    VALID_DATA_TYPES below.
    is_multiple: valid for the text datatype. If {}, the field is to be
    treated as a single term. If not None, it contains a dict of the form
            {'cache_to_list': ',',
             'ui_to_list': ',',
             'list_to_ui': ', '}
    where the cache_to_list contains the character used to split the value in
    the meta2 table, ui_to_list contains the character used to create a list
    from a value shown in the ui (each resulting value must be strip()ed and
    empty values removed), and list_to_ui contains the string used in join()
    to create a displayable string from the list.

    kind == field: is a db field.
    kind == category: standard tag category that isn't a field. see news.
    kind == user: user-defined tag category.
    kind == search: saved-searches category.

    is_category: is a tag browser category. If true, then:
       table: name of the db table used to construct item list
       column: name of the column in the normalized table to join on
       link_column: name of the column in the connection table to join on. This
                    key should not be present if there is no link table
       category_sort: the field in the normalized table to sort on. This
                      key must be present if is_category is True
       If these are None, then the category constructor must know how
       to build the item list (e.g., formats, news).
       The order below is the order that the categories will
       appear in the tags pane.

    name: the text that is to be used when displaying the field. Column headings
    in the GUI, etc.

    search_terms: the terms that can be used to identify the field when
    searching. They can be thought of as aliases for metadata keys, but are only
    valid when passed to search().

    is_custom: the field has been added by the user.

    rec_index: the index of the field in the db metadata record.

    is_csp: field contains colon-separated pairs. Must also be text, is_multiple

    """

    VALID_DATA_TYPES = frozenset(
        [
            None,
            "rating",
            "text",
            "comments",
            "datetime",
            "int",
            "float",
            "bool",
            "series",
            "composite",
            "enumeration",
        ]
    )

    # search labels that are not db columns
    search_items = ["all", "search"]

    def __init__(self):
        super(FieldMetadata, self).__init__()
        self._field_metadata = _builtin_field_metadata()
        self._tb_cats = OrderedDict()
        self._tb_custom_fields = {}
        self._search_term_map = {}
        self.custom_label_to_key_map = {}

        for k, v in self._field_metadata:
            if v["kind"] == "field" and v["datatype"] not in self.VALID_DATA_TYPES:
                raise ValueError("Unknown datatype %s for field %s" % (v["datatype"], k))
            self._tb_cats[k] = v
            self._tb_cats[k]["label"] = k
            self._tb_cats[k]["display"] = {}
            self._tb_cats[k]["is_editable"] = True
            self._add_search_terms_to_map(k, v["search_terms"])

        self._tb_cats["timestamp"]["display"] = {"date_format": tweaks["gui_timestamp_display_format"]}
        self._tb_cats["pubdate"]["display"] = {"date_format": tweaks["gui_pubdate_display_format"]}
        self._tb_cats["last_modified"]["display"] = {"date_format": tweaks["gui_last_modified_display_format"]}
        self.custom_field_prefix = "#"
        self.get = self._tb_cats.get

    def __getitem__(self, key):
        if key == "title_sort":
            return self._tb_cats["sort"]
        return self._tb_cats[key]

    def __setitem__(self, key, val):
        raise AttributeError("Assigning to this object is forbidden")

    def __delitem__(self, key):
        del self._tb_cats[key]

    def __iter__(self):
        for key in self._tb_cats:
            yield key

    def __contains__(self, key):
        return key in self._tb_cats or key == "title_sort"

    def has_key(self, key):
        return key in self

    def keys(self):
        return self._tb_cats.keys()

    def sortable_field_keys(self):
        return [
            k
            for k in self._tb_cats.keys()
            if self._tb_cats[k]["kind"] == "field" and self._tb_cats[k]["datatype"] is not None
        ]

    def displayable_field_keys(self):
        return [
            k
            for k in self._tb_cats.keys()
            if self._tb_cats[k]["kind"] == "field"
            and self._tb_cats[k]["datatype"] is not None
            and k not in ("au_map", "marked", "ondevice", "cover", "series_sort")
            and not self.is_series_index(k)
        ]

    def standard_field_keys(self):
        return [
            k for k in self._tb_cats.keys() if self._tb_cats[k]["kind"] == "field" and not self._tb_cats[k]["is_custom"]
        ]

    def custom_field_keys(self, include_composites=True):
        res = []
        for k in self._tb_cats.keys():
            fm = self._tb_cats[k]
            if fm["kind"] == "field" and fm["is_custom"] and (fm["datatype"] != "composite" or include_composites):
                res.append(k)
        return res

    def all_field_keys(self):
        return [k for k in self._tb_cats.keys() if self._tb_cats[k]["kind"] == "field"]

    def iterkeys(self):
        for key in self._tb_cats:
            yield key

    def itervalues(self):
        return itervalues(self._tb_cats)

    def values(self):
        return self._tb_cats.values()

    def iteritems(self):
        for key in self._tb_cats:
            yield (key, self._tb_cats[key])

    def custom_iteritems(self):
        for key, meta in iteritems(self._tb_custom_fields):
            yield (key, meta)

    def items(self):
        return list(iteritems(self))

    def is_custom_field(self, key):
        return key.startswith(self.custom_field_prefix)

    def is_ignorable_field(self, key):
        """
        Custom fields and user categories are ignorable
        :param key:
        :return:
        """
        return self.is_custom_field(key) or key.startswith("@")

    def ignorable_field_keys(self):
        return [k for k in iterkeys(self._tb_cats) if self.is_ignorable_field(k)]

    def is_series_index(self, key):
        try:
            m = self._tb_cats[key]
            return m["datatype"] == "float" and key.endswith("_index") and key[:-6] in self._tb_cats
        except (KeyError, ValueError, TypeError, AttributeError):
            return False

    def key_to_label(self, key):
        if "label" not in self._tb_cats[key]:
            return key
        return self._tb_cats[key]["label"]

    def label_to_key(self, label, prefer_custom=False):
        if prefer_custom:
            if label in self.custom_label_to_key_map:
                return self.custom_label_to_key_map[label]
        if "label" in self._tb_cats:
            return label
        if not prefer_custom:
            if label in self.custom_label_to_key_map:
                return self.custom_label_to_key_map[label]
        raise ValueError("Unknown key [%s]" % label)

    def all_metadata(self):
        l = {}
        for k in self._tb_cats:
            l[k] = self._tb_cats[k]
        return l

    def custom_field_metadata(self, include_composites=True):
        if include_composites:
            return self._tb_custom_fields
        l = {}
        for k in self.custom_field_keys(False):
            l[k] = self._tb_cats[k]
        return l

    def add_custom_field(
        self,
        label,
        table,
        column,
        datatype,
        colnum,
        name,
        display,
        is_editable,
        is_multiple,
        is_category,
        is_csp=False,
        in_table="books",
    ):
        """
        Add a custom field to the database.
        :param label:
        :param table:
        :param column:
        :param datatype:
        :param colnum:
        :param name:
        :param display:
        :param is_editable:
        :param is_multiple:
        :param is_category:
        :param is_csp: Is composite?
        :return:
        """
        key = self.custom_field_prefix + label
        if key in self._tb_cats:
            raise ValueError("Duplicate custom field [%s]" % label)
        if datatype not in self.VALID_DATA_TYPES:
            raise ValueError("Unknown datatype %s for field %s" % (datatype, key))
        self._tb_cats[key] = {
            "table": table,
            "column": column,
            "datatype": datatype,
            "is_multiple": is_multiple,
            "kind": "field",
            "name": name,
            "search_terms": [key],
            "label": label,
            "colnum": colnum,
            "display": display,
            "is_custom": True,
            "is_category": is_category,
            "link_column": "value",
            "category_sort": "value",
            "is_csp": is_csp,
            "is_editable": is_editable,
            "in_table": in_table,
        }
        self._tb_custom_fields[key] = self._tb_cats[key]
        self._add_search_terms_to_map(key, [key])
        self.custom_label_to_key_map[label] = key
        if datatype == "series":
            key += "_index"
            self._tb_cats[key] = {
                "table": None,
                "column": None,
                "datatype": "float",
                "is_multiple": {},
                "kind": "field",
                "name": "",
                "search_terms": [key],
                "label": label + "_index",
                "colnum": None,
                "display": {},
                "is_custom": False,
                "is_category": False,
                "link_column": None,
                "category_sort": None,
                "is_editable": False,
                "is_csp": False,
                "in_table": in_table,
            }
            self._add_search_terms_to_map(key, [key])
            self.custom_label_to_key_map[label + "_index"] = key

    def remove_dynamic_categories(self):
        for key in list(self._tb_cats.keys()):
            val = self._tb_cats[key]
            if val["is_category"] and val["kind"] in ("user", "search"):
                for k in self._tb_cats[key]["search_terms"]:
                    if k in self._search_term_map:
                        del self._search_term_map[k]
                del self._tb_cats[key]

    def remove_user_categories(self):
        for key in list(self._tb_cats.keys()):
            val = self._tb_cats[key]
            if val["is_category"] and val["kind"] == "user":
                for k in self._tb_cats[key]["search_terms"]:
                    if k in self._search_term_map:
                        del self._search_term_map[k]
                del self._tb_cats[key]

    def _remove_grouped_search_terms(self):
        to_remove = [v for v in self._search_term_map if isinstance(self._search_term_map[v], list)]
        for v in to_remove:
            del self._search_term_map[v]

    def add_grouped_search_terms(self, gst):
        self._remove_grouped_search_terms()
        for t in gst:
            try:
                self._add_search_terms_to_map(gst[t], [t])
            except ValueError:
                traceback.print_exc()

    def cc_series_index_column_for(self, key):
        return self._tb_cats[key]["rec_index"] + 1

    def add_user_category(self, label, name):
        if label in self._tb_cats:
            raise ValueError("Duplicate user field [%s]" % label)
        st = [label]
        if icu_lower(label) != label:
            st.append(icu_lower(label))
        self._tb_cats[label] = {
            "table": None,
            "column": None,
            "datatype": None,
            "is_multiple": {},
            "kind": "user",
            "name": name,
            "search_terms": st,
            "is_custom": False,
            "is_category": True,
            "is_csp": False,
        }
        self._add_search_terms_to_map(label, st)

    def add_search_category(self, label, name):
        if label in self._tb_cats:
            raise ValueError("Duplicate user field [%s]" % label)
        self._tb_cats[label] = {
            "table": None,
            "column": None,
            "datatype": None,
            "is_multiple": {},
            "kind": "search",
            "name": name,
            "search_terms": [],
            "is_custom": False,
            "is_category": True,
            "is_csp": False,
        }

    def set_field_record_index(self, label, index, prefer_custom=False):
        if prefer_custom:
            key = self.custom_field_prefix + label
            if key not in self._tb_cats:
                key = label
        else:
            if label in self._tb_cats:
                key = label
            else:
                key = self.custom_field_prefix + label
        self._tb_cats[key]["rec_index"] = index  # let the exception fly ...

    def get_search_terms(self):
        s_keys = sorted(self._search_term_map.keys())
        for v in self.search_items:
            s_keys.append(v)
        return s_keys

    def _add_search_terms_to_map(self, key, terms):
        if terms is not None:
            for t in terms:
                if t in self._search_term_map:
                    raise ValueError('Attempt to add duplicate search term "%s"' % t)
                self._search_term_map[t] = key

    def search_term_to_field_key(self, term):
        return self._search_term_map.get(term, term)

    def searchable_fields(self):
        return [
            k
            for k in self._tb_cats.keys()
            if self._tb_cats[k]["kind"] == "field" and len(self._tb_cats[k]["search_terms"]) > 0
        ]
