
"""
Contains event dataclasses used to talk to the core.
"""

