
"""
Stores files and metadata.
"""