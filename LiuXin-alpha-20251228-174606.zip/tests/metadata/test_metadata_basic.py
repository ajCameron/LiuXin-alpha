
"""
Testing the metadata representation objects.
"""

from LiuXin_alpha.metadata.containers.calibre_like_book_metadata import CalibreLikeLiuXinBookMetaData





