
"""
Generic tests for ANY location class.
"""