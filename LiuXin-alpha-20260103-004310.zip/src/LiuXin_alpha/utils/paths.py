

"""
Path manip tools.
"""

import os

relpath = os.path.relpath

# probably safe


