
from LiuXin_alpha.utils.logging.event_logs.in_memory_list import InMemoryEventLog

DefaultEventLog = InMemoryEventLog

__all__ = ["DefaultEventLog", ]

