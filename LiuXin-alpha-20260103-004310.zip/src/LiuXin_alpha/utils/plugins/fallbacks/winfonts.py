# -*- coding: utf-8 -*-
"""
Pure-python fallback for the compiled ``winfonts`` extension.

Stub.
"""

from __future__ import annotations


def font_families():
    return []
