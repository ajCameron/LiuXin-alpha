# Pure-python fallback implementations for compiled plugins
