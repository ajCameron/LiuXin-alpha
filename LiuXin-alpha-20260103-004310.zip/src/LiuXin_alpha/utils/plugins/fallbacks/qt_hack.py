# -*- coding: utf-8 -*-
"""
Pure-python fallback for the compiled ``qt_hack`` extension.

The compiled extension typically applies low-level Qt patches. Stub.
"""

from __future__ import annotations
