# -*- coding: utf-8 -*-
"""
Pure-python fallback for the compiled ``chm_extra`` extension.

Stub.
"""

from __future__ import annotations
