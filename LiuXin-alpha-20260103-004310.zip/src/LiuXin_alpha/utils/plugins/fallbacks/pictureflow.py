# -*- coding: utf-8 -*-
"""
Pure-python fallback for the compiled ``pictureflow`` plugin.

This plugin is UI/Qt oriented; this fallback is a stub.
"""

from __future__ import annotations
