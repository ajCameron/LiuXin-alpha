#!/usr/bin/env python
# vim:fileencoding=UTF-8:ts=4:sw=4:sta:et:sts=4:fdm=marker:ai

from __future__ import unicode_literals, division, absolute_import, print_function

import os
import sys
import re
from builtins import zip as izip

from clint.textui import puts
from clint.textui import colored as clint_colored

from LiuXin_alpha.utils.which_os import iswindows
from LiuXin_alpha.utils.libraries.liuxin_six import iteritems

__license__ = "GPL v3"
__copyright__ = "2012, Kovid Goyal <kovid at kovidgoyal.net>"
__docformat__ = "restructuredtext en"


def fmt(code):
    return ("\033[%dm" % code).encode("ascii")


RATTRIBUTES = dict(
    izip(
        range(1, 9),
        ("bold", "dark", "", "underline", "blink", "", "reverse", "concealed"),
    )
)
ATTRIBUTES = {v: fmt(k) for k, v in iteritems(RATTRIBUTES)}
del ATTRIBUTES[""]

RBACKGROUNDS = dict(
    izip(
        range(41, 48),
        ("red", "green", "yellow", "blue", "magenta", "cyan", "white"),
    )
)
BACKGROUNDS = {v: fmt(k) for k, v in iteritems(RBACKGROUNDS)}

RCOLORS = dict(
    izip(
        range(31, 38),
        (
            "red",
            "green",
            "yellow",
            "blue",
            "magenta",
            "cyan",
            "white",
        ),
    )
)
COLORS = {v: fmt(k) for k, v in iteritems(RCOLORS)}

RESET = fmt(0)

if iswindows:
    # From wincon.h
    WCOLORS = {c: i for i, c in enumerate(("black", "blue", "green", "cyan", "red", "magenta", "yellow", "white"))}

    def to_flag(fg, bg, bold):
        val = 0
        if bold:
            val |= 0x08
        if fg in WCOLORS:
            val |= WCOLORS[fg]
        if bg in WCOLORS:
            val |= WCOLORS[bg] << 4
        return val


def colored(text, fg=None, bg=None, bold=False):
    prefix = []
    if fg is not None:
        prefix.append(COLORS[fg])
    if bg is not None:
        prefix.append(BACKGROUNDS[bg])
    if bold:
        prefix.append(ATTRIBUTES["bold"])
    prefix = b"".join(prefix)
    suffix = RESET
    if isinstance(text, type("")):
        prefix = prefix.decode("ascii")
        suffix = suffix.decode("ascii")
    return prefix + text + suffix


class Detect(object):
    def __init__(self, stream):
        self.stream = stream or sys.stdout
        self.isatty = getattr(self.stream, "isatty", lambda: False)()
        force_ansi = "CALIBRE_FORCE_ANSI" in os.environ
        if not self.isatty and force_ansi:
            self.isatty = True
        self.isansi = force_ansi or not iswindows
        self.set_console = self.write_console = None
        self.is_console = False
        if not self.isansi:
            try:
                import msvcrt

                self.msvcrt = msvcrt
                self.file_handle = msvcrt.get_osfhandle(self.stream.fileno())
                from ctypes import (
                    windll,
                    wintypes,
                    byref,
                    c_wchar_p,
                    c_size_t,
                    POINTER,
                    WinDLL,
                )

                mode = wintypes.DWORD(0)
                f = windll.kernel32.GetConsoleMode
                f.argtypes, f.restype = [
                    wintypes.HANDLE,
                    POINTER(wintypes.DWORD),
                ], wintypes.BOOL
                if f(self.file_handle, byref(mode)):
                    # Stream is a console
                    self.set_console = windll.kernel32.SetConsoleTextAttribute
                    self.wcslen = crt().wcslen
                    self.wcslen.argtypes, self.wcslen.restype = [c_wchar_p], c_size_t
                    self.write_console = WinDLL("kernel32", use_last_error=True).WriteConsoleW
                    self.write_console.argtypes = [
                        wintypes.HANDLE,
                        wintypes.c_wchar_p,
                        wintypes.DWORD,
                        POINTER(wintypes.DWORD),
                        wintypes.LPVOID,
                    ]
                    self.write_console.restype = wintypes.BOOL
                    self.is_console = True
            except:
                pass

    def write_unicode_text(self, text, ignore_errors=False):
        "Windows only method that writes unicode strings correctly to the windows console using the Win32 API"
        if self.is_console:
            from ctypes import wintypes, byref, c_wchar_p

            written = wintypes.DWORD(0)
            chunk = len(text)
            while text:
                t, text = text[:chunk], text[chunk:]
                wt = c_wchar_p(t)
                if not self.write_console(self.file_handle, wt, self.wcslen(wt), byref(written), None):
                    # Older versions of windows can fail to write large strings
                    # to console with WriteConsoleW (seen it happen on Win XP)
                    import ctypes, winerror

                    err = ctypes.get_last_error()
                    if err == winerror.ERROR_NOT_ENOUGH_MEMORY and chunk >= 128:
                        # Retry with a smaller chunk size (give up if chunk < 128)
                        chunk = chunk // 2
                        text = t + text
                        continue
                    if err == winerror.ERROR_GEN_FAILURE:
                        # On newer windows, this happens when trying to write
                        # non-ascii chars to the console and the console is set
                        # to use raster fonts (the default). In this case
                        # rather than failing, write an informative error
                        # message and the asciized version of the text.
                        print(
                            "Non-ASCII text detected. You must set your Console's font to"
                            " Lucida Console or Consolas or some other TrueType font to see this text",
                            file=self.stream,
                            end=" -- ",
                        )
                        from LiuXin.utils.calibre.utils.filenames import ascii_text

                        print(ascii_text(t + text), file=self.stream, end="")
                        continue
                    if not ignore_errors:
                        raise ctypes.WinError(err)


_crt = None


def crt():
    # We use the C runtime bundled with the calibre windows build
    global _crt
    if _crt is None:
        import glob, ctypes

        d = os.path.join(os.path.dirname(sys.executable), "*.CRT", "msvcr*.dll")
        _crt = ctypes.CDLL(glob.glob(d)[0])
    return _crt


class ColoredStream(Detect):
    def __init__(self, stream=None, fg=None, bg=None, bold=False):
        super(ColoredStream, self).__init__(stream)
        self.fg, self.bg, self.bold = fg, bg, bold
        if self.set_console is not None:
            self.wval = to_flag(self.fg, self.bg, bold)

    def __enter__(self):
        if not self.isatty:
            return self
        if self.isansi:
            if self.bold:
                self.stream.write(ATTRIBUTES["bold"])
            if self.bg is not None:
                self.stream.write(BACKGROUNDS[self.bg])
            if self.fg is not None:
                self.stream.write(COLORS[self.fg])
        elif self.set_console is not None:
            if self.wval != 0:
                self.set_console(self.file_handle, self.wval)
        return self

    def __exit__(self, *args, **kwargs):
        if not self.isatty:
            return
        if not self.fg and not self.bg and not self.bold:
            return
        if self.isansi:
            self.stream.write(RESET)
        elif self.set_console is not None:
            self.set_console(self.file_handle, WCOLORS["white"])


class ANSIStream(Detect):

    ANSI_RE = re.compile(rb"\033\[((?:\d|;)*)([a-zA-Z])")

    def __init__(self, stream=None):
        super(ANSIStream, self).__init__(stream)
        self.encoding = getattr(self.stream, "encoding", "utf-8") or "utf-8"

    def write(self, text):
        if isinstance(text, type("")):
            text = text.encode(self.encoding, "replace")

        if not self.isatty:
            return self.strip_and_write(text)

        if self.isansi:
            return self.stream.write(text)

        if not self.isansi and self.set_console is None:
            return self.strip_and_write(text)

        self.write_and_convert(text)

    def strip_and_write(self, text):
        self.stream.write(self.ANSI_RE.sub(b"", text))

    def write_and_convert(self, text):
        """
        Write the given text to our wrapped stream, stripping any ANSI sequences from the text, and optionally
        converting them into win32 calls.
        :param text:
        :return:
        """
        self.last_state = (None, None, False)
        cursor = 0
        for match in self.ANSI_RE.finditer(text):
            start, end = match.span()
            self.write_plain_text(text, cursor, start)
            self.convert_ansi(*match.groups())
            cursor = end
        self.write_plain_text(text, cursor, len(text))
        self.stream.flush()

    def write_plain_text(self, text, start, end):
        if start < end:
            text = text[start:end]
            if self.is_console and isinstance(text, bytes):
                try:
                    utext = text.decode(self.encoding)
                except ValueError:
                    pass
                else:
                    return self.write_unicode_text(utext)
            self.stream.write(text)

    def convert_ansi(self, paramstring, command):
        params = self.extract_params(paramstring)
        self.call_win32(command, params)

    def extract_params(self, paramstring):
        def split(paramstring):
            for p in paramstring.split(b";"):
                if p:
                    yield int(p)

        return tuple(split(paramstring))

    def call_win32(self, command, params):
        if command != b"m":
            return
        fg, bg, bold = self.last_state

        for param in params:
            if param in RCOLORS:
                fg = RCOLORS[param]
            elif param in RBACKGROUNDS:
                bg = RBACKGROUNDS[param]
            elif param == 1:
                bold = True
            elif param == 0:
                fg = "white"
                bg, bold = None, False

        self.last_state = (fg, bg, bold)
        if fg or bg or bold:
            self.set_console(self.file_handle, to_flag(fg, bg, bold))
        else:
            self.set_console(self.file_handle, WCOLORS["white"])


def windows_terminfo():
    from ctypes import Structure, byref
    from ctypes.wintypes import SHORT, WORD

    class COORD(Structure):

        """struct in wincon.h"""

        _fields_ = [
            ("X", SHORT),
            ("Y", SHORT),
        ]

    class SMALL_RECT(Structure):

        """struct in wincon.h."""

        _fields_ = [
            ("Left", SHORT),
            ("Top", SHORT),
            ("Right", SHORT),
            ("Bottom", SHORT),
        ]

    class CONSOLE_SCREEN_BUFFER_INFO(Structure):

        """struct in wincon.h."""

        _fields_ = [
            ("dwSize", COORD),
            ("dwCursorPosition", COORD),
            ("wAttributes", WORD),
            ("srWindow", SMALL_RECT),
            ("dwMaximumWindowSize", COORD),
        ]

    csbi = CONSOLE_SCREEN_BUFFER_INFO()
    import msvcrt

    file_handle = msvcrt.get_osfhandle(sys.stdout.fileno())
    from ctypes import windll

    success = windll.kernel32.GetConsoleScreenBufferInfo(file_handle, byref(csbi))
    if not success:
        raise Exception("stdout is not a console?")
    return csbi


def geometry():
    if iswindows:
        try:

            ti = windows_terminfo()
            return (ti.dwSize.X or 80, ti.dwSize.Y or 80)
        except:
            return 80, 80
    try:
        import curses

        curses.setupterm()
    except:
        return 80, 80
    else:
        width = curses.tigetnum("cols") or 80
        height = curses.tigetnum("lines") or 80
        return width, height


def test():
    s = ANSIStream()

    text = [
        colored(t, fg=t) + ". " + colored(t, fg=t, bold=True) + "."
        for t in (
            "red",
            "yellow",
            "green",
            "white",
            "cyan",
            "magenta",
            "blue",
        )
    ]
    s.write("\n".join(text))
    u = "\u041c\u0438\u0445\u0430\u0438\u043b fällen"
    print()
    s.write_unicode_text(u)
    print()


# Todo: Implement this as part of actually making the progress grid work - THIS IS A REALLY GOOD IDEA
# Even if it wasn't actually needed to make the progress grid
class RestorePosition(object):
    """
    Context manager to restore the cursor to it's original position after preforming an operation.
    """

    # https://stackoverflow.com/questions/35526014/how-can-i-get-the-cursors-position-in-an-ansi-terminal
    def __enter__(self):
        pass

    def __exit__(self, exc_type, exc_val, exc_tb):
        pass


def getTerminalSize():
    """
    Returns a tuple of the height and width of the terminal window.
    :return (width, height):
    """
    import os

    env = os.environ

    def ioctl_GWINSZ(fd):
        try:
            import fcntl, termios, struct, os

            cr = struct.unpack("hh", fcntl.ioctl(fd, termios.TIOCGWINSZ, "1234"))
        except:
            return
        return cr

    cr = ioctl_GWINSZ(0) or ioctl_GWINSZ(1) or ioctl_GWINSZ(2)
    if not cr:
        try:
            fd = os.open(os.ctermid(), os.O_RDONLY)
            cr = ioctl_GWINSZ(fd)
            os.close(fd)
        except:
            pass
    if not cr:
        cr = (env.get("LINES", 25), env.get("COLUMNS", 80))

        ### Use get(key[, default]) instead of a try/catch
        # try:
        #    cr = (env['LINES'], env['COLUMNS'])
        # except:
        #    cr = (25, 80)
    return int(cr[1]), int(cr[0])


# Todo: Make this _actually_ safe
def safe_terminal_info_print(info_strs):
    """
    Reliably display text in the terminal - displays in green when possible.
    :param info_strs: A list of the strings to display - strings will be joined and printed
    :return:
    """
    term_width, term_height = getTerminalSize()
    info_strs = (
        [
            "#" * term_width,
        ]
        + info_strs
        + [
            "#" * term_width,
        ]
    )
    puts(clint_colored.green("\n".join(info_strs)))
