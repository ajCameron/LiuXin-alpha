# Package marker for calibre compatibility shims.
