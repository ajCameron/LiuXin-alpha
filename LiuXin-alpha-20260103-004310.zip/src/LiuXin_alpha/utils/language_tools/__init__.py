
from LiuXin_alpha.utils.language_tools.pluralizers import singular_plural_mapper, plural_singular_mapper

__all__ = ["singular_plural_mapper", "plural_singular_mapper"]
