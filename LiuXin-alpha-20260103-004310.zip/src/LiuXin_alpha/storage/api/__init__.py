
"""
Contains the fundamental APIs for the storage class.
"""

# Todo: Rules about what can be stored in which store?

from __future__ import annotations




# --- path-ish inputs ---


# ----------------------------
# Helpers: run async from sync
# ----------------------------


# ---------------------------------
# Helpers: run sync work from async
# ---------------------------------





