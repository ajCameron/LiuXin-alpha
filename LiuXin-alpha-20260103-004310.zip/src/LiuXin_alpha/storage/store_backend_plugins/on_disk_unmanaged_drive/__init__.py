
"""
Part of the idea of LiuXin is you can include files which are not part of the system.

(should you? Probably not. But the option exists).
The aim for this is to allow you to track and manipulate files which are not, otherwise, on the system.
In this case, for slightly esoteric backup purposes.
"""












