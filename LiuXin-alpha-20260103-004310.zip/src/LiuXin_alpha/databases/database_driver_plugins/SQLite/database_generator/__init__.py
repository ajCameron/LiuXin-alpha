
# Front end for the database_generator
from LiuXin_alpha.databases.database_driver_plugins.SQLite.database_generator.database_generator import (
    create_new_database,
)

__author__ = "Cameron"

__all__ = ["create_new_database", ]


