
"""
API for the database and related classes.
"""

import abc


class DatabaseBuilderAPI(abc.ABC):
    """
    API for the fundamental database builder class.
    """

    @abc.abstractmethod
    def set_database_version(self) -> None:
        """
        Set the database version.

        :return:
        """


class RowAPI(abc.ABC):
    """
    API for a row off the database.
    """



class DatabaseDriverAPI(abc.ABC):
    """
    Every database drive must descend from this class.
    """



class DatabaseAPI(abc.ABC):
    """
    API for the Database itself.
    """



class DatabaseCacheAPI(abc.ABC):
    """
    Every local cache containing data from the database must descend from this class.
    """



