
"""
Creator container - contains creator information.
"""



