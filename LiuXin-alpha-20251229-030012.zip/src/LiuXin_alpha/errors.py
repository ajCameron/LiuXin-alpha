
"""
Base class for ALL errors that LiuXin should ever throw.
"""

# -------------
# - BASE ERRORS


class LiuXinException(Exception):
    """
    Base LiuXin exception - should be at the root of every exception.
    """


class BadInputException(LiuXinException):
    """
    Are you _sure_ you meant that?
    """

InputIntegrityError = BadInputException


class LogicalError(LiuXinException):
    def __init__(self, argument=None):
        if argument is not None:
            self.argument = argument
            if argument is not None:
                print(self.argument)
        else:
            pass

    def __str__(self):
        return repr(self.argument)



class TimedOutError(LiuXinException):
    """
    To be used when a process has timed out - generic replacement which should always be raised instead of whatever
    custom exception the code originally raised.
    """
    pass


# -------------


# -----------------
# - DATABASE ERRORS

class LiuXinDatabaseException(LiuXinException):
    """
    Base LiuXin database exception - should be at the root of every database exception.
    """


class InvalidUpdate(LiuXinDatabaseException):
    """
    Generic class for when a database update cannot be processed.
    """

    pass


class InvalidCacheUpdate(InvalidUpdate):
    """
    Called when an update to the cache is invalid for some reason.
    Subclass this error for the specific ways that the update might be invalid.
    """
    pass


class InvalidDBUpdate(InvalidUpdate):
    """
    Called when an update to the database is invalid for some reason.
    Subclass this error for the specific ways that the update might be invalid.
    """
    pass


class NotInDatabaseError(LiuXinDatabaseException):
    """
    Called when the database fails to retrieve a row which is expected to be found.
    """
    pass


class RowReadOnlyError(LiuXinDatabaseException):
    """
    Called when you try and update the database through a row which is read only.
    """
    pass


class DatabaseIntegrityError(LiuXinDatabaseException):
    """
    Somethig you've done has brought the database into a compromised state.
    """
    def __init__(self, argument):
        if argument is not None:
            self.argument = argument
        else:
            self.argument = None

    def __str__(self):
        return repr(self.argument)  # Todo: Should be unicode



# -----------------

# -----------------
# - TEST EXCEPTIONS

class CompromisedTestObjectCache(LiuXinException):
    """
    Raised when it's detected that the in memory cache for test objects is in a compromised state.
    """
    pass

# -----------------

# -------------------
# - CONVERSION ERRORS

class LiuXinConversionError(LiuXinException):
    def __init__(self, msg, only_msg=False):
        Exception.__init__(self, msg)
        self.only_msg = only_msg


ConversionError = LiuXinConversionError


class UnknownFormatError(Exception):
    """

    """
    pass


class DRMError(ValueError):
    pass


class ParserError(ValueError):
    pass


# -------------------






class NoSuchBook(Exception):
    pass


class NotInCache(Exception):
    pass


class NoSuchFormatInCache(NotInCache):
    pass


class NotInCoverCache(NotInCache):
    pass


class ImportCacheError(Exception):
    pass


class NotInImportCache(NotInCache):
    pass





class DatabaseConstraintError(Exception):
    def __init__(self, argument):
        if argument is not None:
            self.argument = argument
        else:
            self.argument = None

    def __str__(self):
        return repr(self.argument)  # Todo: Should be unicode


class ImportError(Exception):
    def __init__(self, argument=None):
        if argument is not None:
            self.argument = argument
            if argument is not None:
                LiuXin_print(self.argument)
        else:
            pass

    def __str__(self):
        return repr(self.argument)




class InputIntegrityError(Exception):
    def __init__(self, argument=None):
        if argument is not None:
            self.argument = argument
            if argument is not None:
                LiuXin_print(self.argument)
        else:
            pass

    def __str__(self):
        return repr(self.argument)


class FolderStoreIntegrityError(Exception):
    def __init__(self, argument=None):
        if argument is not None:
            self.argument = argument
            if argument is not None:
                LiuXin_print(self.argument)
        else:
            pass

    def __str__(self):
        return repr(self.argument)


class InvalidFolderStore(Exception):
    """
    An exception raised if there is some terminal problem importing a folder store driver.
    """

    def __init__(self, argument):
        self.err_str = argument
        if argument is not None:
            LiuXin_print(self.argument)


class InvalidFolderStoreDriver(Exception):
    """
    An exception raised if there is some terminal problem importing a folder store driver.
    """

    def __init__(self, err_str):
        self.err_str = err_str
        print(self.err_str)


class DatabaseDriverError(Exception):
    def __init__(self, argument=None):
        if argument is not None:
            self.argument = argument
            if argument is not None:
                LiuXin_print(self.argument)
        else:
            pass

    def __str__(self):
        return repr(self.argument)


class DatabaseIntegrityError(Exception):
    def __init__(self, argument):
        self.argument = argument
        if argument is not None:
            LiuXin_print(self.argument)

    def __str__(self):
        return repr(self.argument)


class RowIntegrityError(Exception):
    def __init__(self, argument):
        self.argument = argument
        if argument is not None:
            LiuXin_print(self.argument)

    def __str__(self):
        return repr(self.argument)


class PreferenceError(Exception):
    def __init__(self, argument):
        self.argument = argument
        if argument is not None:
            LiuXin_print(self.argument)

    def __str__(self):
        return repr(self.argument)


class SQLParseError(Exception):
    def __init__(self, argument):
        self.argument = argument
        if argument is not None:
            LiuXin_print(self.argument)

    def __str__(self):
        return repr(self.argument)


class SearchParseError(Exception):
    """
    Error for when parsing a search query goes horribly wrong.
    """

    def __init__(self, argument):
        self.argument = argument
        if argument is not None:
            LiuXin_print(self.argument)

    def __str__(self):
        return repr(self.argument)


class FSDriverError(Exception):
    """
    Error for when something goes wrong at the FolderStoreDriver level.
    """

    def __init__(self, argument):
        self.argument = argument
        if argument is not None:
            LiuXin_print(self.argument)

    def __str__(self):
        return repr(self.argument)


class FSError(Exception):
    """
    Error for when something goes wrong at the FolderStoreDriver level.
    """

    def __init__(self, argument):
        self.argument = argument
        if argument is not None:
            LiuXin_print(self.argument)

    def __str__(self):
        return repr(self.argument)


class FolderStoreError(Exception):
    """
    Error for when something goes wrong at the FolderStoreDriver level.
    """

    def __init__(self, argument):
        self.argument = argument
        if argument is not None:
            LiuXin_print(self.argument)

    def __str__(self):
        return repr(self.argument)


class FolderError(Exception):
    """
    Error for when something goes wrong at the Folder level.
    """

    def __init__(self, argument):
        self.argument = argument
        if argument is not None:
            LiuXin_print(self.argument)

    def __str__(self):
        return repr(self.argument)


class ResourceError(Exception):
    """
    Error for when something goes wrong at the Folder level.
    """

    def __init__(self, argument):
        self.argument = argument
        if argument is not None:
            LiuXin_print(self.argument)

    def __str__(self):
        return repr(self.argument)


class LXImportError(Exception):
    """
    Error for when something goes wrong when trying to import a file or folder.
    """

    def __init__(self, argument):
        self.argument = argument
        if argument is not None:
            LiuXin_print(self.argument)

    def __str__(self):
        return repr(self.argument)


class LocationError(Exception):
    """
    Error for when something goes wrong when trying to read/write/determine properties of a location .
    """

    def __init__(self, argument):
        self.argument = argument
        if argument is not None:
            LiuXin_print(self.argument)

    def __str__(self):
        return repr(self.argument)


class PlatformError(Exception):
    """
    Error for when something goes wrong due to a method intended for another platform being called on the wrong
    platform.
    """

    def __init__(self, argument):
        self.argument = argument
        if argument is not None:
            LiuXin_print(self.argument)

    def __str__(self):
        return repr(self.argument)


# ----------------------------------------------------------------------------------------------------------------------
#
# - PLUGIN ERRORS START HERE
#
# ----------------------------------------------------------------------------------------------------------------------


class PluginNotFound(ValueError):
    pass


class InvalidPlugin(ValueError):
    pass


class MetadataReadError(Exception):
    pass


class ArchiveError(Exception):
    """
    Generic exception to be raised if an archive cannot be expanded for some reason.
    """

    pass


# calibre exception
class NoSuchFormat(ValueError):
    pass
