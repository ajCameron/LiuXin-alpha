
"""
The lifecyle and component hub for LiuXin.

LiuXin is a plugin based program.
Registry is responsible for discovering, checking, loading and otherwise preparing these plugins.
If you want almost anything, you're first port of call should be registry.
"""