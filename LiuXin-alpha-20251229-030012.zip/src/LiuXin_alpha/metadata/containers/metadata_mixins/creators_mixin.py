
"""
Mixin to provide creator functionality to metadata objects.
"""


class CreatorsMetadataMixin:
    """
    Mixin to provide creator functionality to metadata objects.
    """




