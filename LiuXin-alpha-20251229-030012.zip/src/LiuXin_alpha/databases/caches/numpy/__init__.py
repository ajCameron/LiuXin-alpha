# Cache with the table data stored in a numpy array
