"""
Contains base classes for the tag class - which represents a tag on the systme.
"""


class BaseTagClass:

    pass
