# Fallbacks for when the main versions of the modules can't be loaded
