# There is a python magick module - which should be the thing which is actually used for this


class Image(object):
    pass


class PixelWand(object):
    pass


class DrawingWand(object):
    pass
