# Fallback pure python package to replace the compiled imageops, if it cannot be loaded
# Uses Imagemagick

# Todo: Use ImageMagick to write fallbacks for as many of the methods in ImageOps as possible
