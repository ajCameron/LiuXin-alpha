def parse_date(date_str):
    raise NotImplementedError
