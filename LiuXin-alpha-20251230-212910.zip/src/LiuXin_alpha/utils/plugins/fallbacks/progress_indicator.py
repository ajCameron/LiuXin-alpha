# Dummy for the progress indicator plugin


def load_style(icon_map):
    """
    This is a dummy for the progress indicator. It has no style.
    :return:
    """
    return 0
