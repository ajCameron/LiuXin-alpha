
#
# import importlib
# import sys
# import os
#
#
# utils_path = os.path.split(__file__)[0]
#
#
# class Plugins:
#     def __init__(self):
#         self._plugins = {}
#         plugins = [
#             "magick",
#             "cPalmdoc",
#         ]
#
#         # Original version preserved for reference purposes
#         # plugins = [
#         #         'pictureflow',
#         #         'lzx',
#         #         'msdes',
#         #         'magick',
#         #         'podofo',
#         #         'cPalmdoc',
#         #         'progress_indicator',
#         #         'chmlib',
#         #         'chm_extra',
#         #         'icu',
#         #         'speedup',
#         #         'html',
#         #         'freetype',
#         #         'woff',
#         #         'unrar',
#         #         'qt_hack',
#         #         '_regex',
#         #         'hunspell',
#         #         '_patiencediff_c',
#         #         'bzzdec',
#         #         'matcher',
#         #         'tokenizer',
#         #     ]
#         # if iswindows:
#         #     plugins.extend(['winutil', 'wpd', 'winfonts'])
#         # if isosx:
#         #     plugins.append('usbobserver')
#         # if islinux or isosx:
#         #     plugins.append('libusb')
#         #     plugins.append('libmtp')
#
#         self.plugins = frozenset(plugins)
#
#     def load_plugin(self, name):
#
#         if name in self._plugins:
#             return
#
#         sys.path.insert(1, utils_path)
#         # sys.path.insert(0, sys.extensions_location)
#         try:
#             del sys.modules[name]
#         except KeyError:
#             pass
#
#         try:
#             p, err = importlib.import_module(name), ""
#         except Exception as err:
#             p = None
#             err = str(err)
#         self._plugins[name] = (p, err)
#         # sys.path.remove(sys.extensions_location)
#         sys.path.remove(utils_path)
#
#     def __iter__(self):
#         return iter(self.plugins)
#
#     def __len__(self):
#         return len(self.plugins)
#
#     def __contains__(self, name):
#         return name in self.plugins
#
#     def __getitem__(self, name):
#         if name not in self.plugins:
#             raise KeyError("No plugin named %r" % name)
#         self.load_plugin(name)
#         return self._plugins[name]
#
#
# # Forces reload of the plugins
# plugins = None
# if plugins is None:
#     plugins = Plugins()


from __future__ import unicode_literals

# Serves as a front end for the compiled C/C++ plugins which LiuXin needs to function

import imp
import importlib
import os
import pprint

from copy import deepcopy

from LiuXin_alpha.constants.paths import LiuXin_base_folder
from LiuXin_alpha.utils.which_os import iswindows, isosx, islinux

compiled_exts_dir = os.path.join(LiuXin_base_folder, "LiuXin_alpha", "utils", "plugins")

# All known plugins
compiled_plugins = [
    "pictureflow",
    "lzx",
    "msdes",
    "magick",
    "podofo",
    "cPalmdoc",
    "progress_indicator",
    "chmlib",
    "chm_extra",
    "icu",
    "imageops",
    "speedup",
    "magick",
    "html",
    "freetype",
    "woff",
    "unrar",
    "qt_hack",
    "_regex",
    "hunspell",
    "_patiencediff_c",
    "bzzdec",
    "matcher",
    "tokenizer",
]


if iswindows:
    compiled_plugins.extend(["winutil", "wpd", "winfonts"])
if isosx:
    compiled_plugins.append("usbobserver")
if islinux or isosx:
    compiled_plugins.append("libusb")
    compiled_plugins.append("libmtp")


class Plugins(object):
    """
    Loads the available plugins.
    """

    def __init__(self):
        """
        Iterates through all the known plugins - tries to load each of them from the compiled extensions folder.
        """
        assert os.path.exists(compiled_exts_dir), "Cannot load - compiled extensions folder not found"

        # compiled_plugins - All the plugins which should be found in the compiled extensions folder under utils
        # status - keyed with the name of the plugin and valued with True (plugin imported and ready for use) or False
        #          (something went wrong - see the module entry in status_str for more information)
        # status_str - keyed with the name of the plugin and valued with a list of strings describing the plugins status
        # __plugin_store - stores the actual plugin objects
        self.compiled_plugins = deepcopy(compiled_plugins)
        self.status = {pn: False for pn in self.compiled_plugins}
        self.status_str = {pn: [] for pn in self.compiled_plugins}
        self.__plugin_store = {pn: None for pn in self.compiled_plugins}

        # Load compiled extensions from LiuXin.utils.compiled_extensions
        if islinux:
            self.__load_compiled_extensions_linux()

            # Load fallbacks to the compiled extensions from LiuXin.utils.compiled_extensions.fallbacks modules
            self.__load_fallbacks()
        else:
            self.__load_fallbacks()

    def __load_compiled_extensions_linux(self):
        """
        Loads the C/C++ compiled extensions which should be stored in LiuXin.utils.compiled_extensions.
        :return:
        """
        for plugin_name in self.compiled_plugins:

            self.status[plugin_name] = False

            # 1) Check to see if the file actually exists to load
            plugin_file_name = "{}.{}".format(plugin_name, "so")
            plugin_file_path = os.path.join(compiled_exts_dir, "linux", plugin_file_name)

            # Check that the file physically exists
            if not os.path.exists(plugin_file_path):
                self.status_str[plugin_name] = [
                    "Couldn't fine plugin file - load aborted - " "path: {}".format(plugin_file_path)
                ]
                continue

            self.status_str[plugin_name] = ["Plugin found - proceeding to load"]

            # 2) Try directly importing the module
            plugin_imp_name = "LiuXin.utils.compiled_extensions.linux.{}".format(plugin_name)
            try:
                loaded_plugin = importlib.import_module(plugin_imp_name)
            except ImportError:
                self.status_str[plugin_name].append("Using importlib.import_module failed with ImportError")
            except RuntimeError:
                self.status_str[plugin_name].append("Using importlib.import_module failed with RuntimeError")
            else:
                self.__plugin_store[plugin_name] = loaded_plugin
                self.status[plugin_name] = True
                self.status_str[plugin_name].append("Imported using importlib.import_module")
                continue

            # 3) Try loading the compiled module
            try:
                loaded_plugin = importlib.load_compiled(plugin_name, plugin_file_path)
            except ImportError:
                self.status_str[plugin_name].append("Using imp.load_compiled failed with ImportError")
            else:
                self.__plugin_store[plugin_name] = loaded_plugin
                self.status[plugin_name] = True
                self.status_str[plugin_name].append("Imported using imp.load_compiled")
                continue

            # 4) Try manual importing
            try:
                loaded_plugin = None
                import_str = "import LiuXin.utils.compiled_extensions.{} as loaded_plugin".format(plugin_name)
                exec(import_str)
            except ImportError:
                self.status_str[plugin_name].append("Importing using exec failed with ImportError")
            else:
                if loaded_plugin is None:
                    self.status_str[plugin_name].append("import_str failed silently")
                else:
                    self.__plugin_store[plugin_name] = loaded_plugin
                    self.status[plugin_name] = True
                    self.status_str[plugin_name].append("Imported using exec")
                    continue

            self.status_str[plugin_name].append("All methods have failed - plugin not imported")

    def __load_fallbacks(self):
        """
        Loads fallbacks from the LiuXin.compiled_extensions.fallbacks module.
        :return:
        """
        for plugin_name in compiled_plugins:

            # No need to load the fallback - the initial plugin seems to have loaded just fine
            if self.status[plugin_name]:
                continue

            plugin_imp_name = "LiuXin.utils.compiled_extensions.fallbacks.{}".format(plugin_name)
            try:
                loaded_plugin = importlib.import_module(plugin_imp_name)
            except ImportError:
                self.status_str[plugin_name].append("Loading fallback using importlib module failed")
            except RuntimeError:
                self.status_str[plugin_name].append(
                    "Fallback plugin cannot be loaded - RunTimeError - probably " "missing a needed resource"
                )
            else:
                self.__plugin_store[plugin_name] = loaded_plugin
                self.status[plugin_name] = True
                self.status_str[plugin_name].append("Fallback imported using importlib.import_module")
                continue

    def __unicode__(self):
        """
        A unicode representation of the known plugins.
        :return:
        """
        rtn_str = "Known Plugins: \n"
        rtn_str += pprint.pformat(self.compiled_plugins, indent=4) + "\n"
        rtn_str += "Loaded Plugins: \n"
        loaded_plugins = [k for k in self.status.keys() if self.status[k]]

        rtn_str += pprint.pformat(loaded_plugins, indent=4) + "\n"
        rtn_str += "Failed Plugins: \n"
        failed_plugins = [k for k in self.status.keys() if not self.status[k]]

        rtn_str += pprint.pformat(failed_plugins, indent=4)

        return rtn_str

    def __str__(self):
        """
        A string representation of the object - calls unicode and then safely encodes the result.
        Falls back on a replace method if the result cannot be encoded properly.
        :return:
        """
        try:
            return self.__unicode__().encode("utf-8")
        except UnicodeEncodeError:
            return self.__unicode__().encode("utf-8", "replace")

    # ------------------------------------------------------------------------------------------------------------------
    # - PLUGIN ACCESS METHODS START HERE
    # ------------------------------------------------------------------------------------------------------------------

    def __getitem__(self, item):
        """
        Calling returns the plugin and, currently, a string "errors are not logged"
        :param item:
        :return:
        """
        if item in self.__plugin_store:
            return self.__plugin_store[item], None
        else:
            info_str = "\n".join(self.status_str[item])
            return None, info_str

    def plugin_okay(self, plugin_name):
        """
        Returns the status of the plugin - True or False.
        Will raise KeyError if the file is not found.
        :param plugin_name:
        :return:
        """
        return self.status[plugin_name]


# Sundry path constants
LiuXin_utils_folder = os.path.join(LiuXin_base_folder, "utils")
LiuXin_plugins_folder = os.path.join(LiuXin_base_folder, "LiuXin_plugins")
LiuXin_calibre_portable = os.path.join(LiuXin_plugins_folder, "Calibre Portable")
LiuXin_calibre_plugins_folder = os.path.join(LiuXin_calibre_portable, "Calibre")

# Paths for the various plugins available to calibre portable
# An install of calibre portable should have come bundled with LiuXin
LiuXin_pdftohtml_path = os.path.join(LiuXin_calibre_plugins_folder, "pdftohtml.exe")
LiuXin_ebook_meta_path = os.path.join(LiuXin_calibre_plugins_folder, "ebook-meta.exe")
# Todo: Rename to be less confusing
LiuXin_calibre_plugins_store = os.path.join(LiuXin_plugins_folder, "plugins from calibre")


# Load
plugins = Plugins()
