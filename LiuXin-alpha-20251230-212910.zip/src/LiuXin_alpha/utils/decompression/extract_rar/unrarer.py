# serves as a unified front end for the various modules here contained

"""
Apparently, I haven't gotten round to writing this yet...
"""


class RarFile:
    ...
