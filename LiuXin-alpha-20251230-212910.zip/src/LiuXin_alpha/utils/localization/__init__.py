



def trans(to_be_localized: str) -> str:
    """
    Translate the given string to the current language.

    Placeholder.
    :param to_be_localized:
    :return:
    """
    return to_be_localized