from __future__ import with_statement

"""
Conversion to EPUB
"""

from LiuXin.utils.calibre_utils.calibre_zipfile import ZipFile, ZIP_STORED

__license__ = "GPL v3"
__copyright__ = "2008, Kovid Goyal kovid@kovidgoyal.net"
__docformat__ = "restructuredtext en"


def rules(stylesheets):
    for s in stylesheets:
        if hasattr(s, "cssText"):
            for r in s:
                if r.type == r.STYLE_RULE:
                    yield r


def initialize_container(path_to_container, opf_name="metadata.opf", extra_entries=None):
    """
    Create an empty EPUB document, with a default skeleton.
    :param path_to_container: Path to the epub container
    :param opf_name: The name of the opf file in the container
    :param extra_entries: Anything else to be tacked onto the epub
    :return:
    """
    if extra_entries is None:
        extra_entries = []

    rootfiles = ""
    for path, mimetype, _ in extra_entries:
        rootfiles += '<rootfile full-path="{0}" media-type="{1}"/>'.format(path, mimetype)
    container = """\
<?xml version="1.0"?>
<container version="1.0" xmlns="urn:oasis:names:tc:opendocument:xmlns:container">
   <rootfiles>
      <rootfile full-path="{0}" media-type="application/oebps-package+xml"/>
      {extra_entries}
   </rootfiles>
</container>
    """.format(
        opf_name, extra_entries=rootfiles
    ).encode(
        "utf-8"
    )
    zf = ZipFile(path_to_container, "w")
    zf.writestr("mimetype", "application/epub+zip", compression=ZIP_STORED)
    zf.writestr("META-INF/", "", 0o0755)
    zf.writestr("META-INF/container.xml", container)
    for path, _, data in extra_entries:
        zf.writestr(path, data)
    return zf
