#!/usr/bin/env python
# vim:fileencoding=UTF-8:ts=4:sw=4:sta:et:sts=4:ai

from __future__ import with_statement

import os

from LiuXin.customize.conversion import InputFormatPlugin, OptionRecommendation

from LiuXin.utils.calibre import walk
from LiuXin.utils.calibre.constants import numeric_version
from LiuXin.utils.localization import trans as _

__license__ = "GPL v3"
__copyright__ = "2009, Kovid Goyal <kovid@kovidgoyal.net>"
__docformat__ = "restructuredtext en"


class RecipeDisabled(Exception):
    pass


class RecipeInput(InputFormatPlugin):

    name = "Recipe Input"
    author = "Kovid Goyal"
    description = _("Download periodical content from the internet")
    file_types = {"recipe", "downloaded_recipe"}

    recommendations = {
        ("chapter", None, OptionRecommendation.HIGH),
        ("dont_split_on_page_breaks", True, OptionRecommendation.HIGH),
        ("use_auto_toc", False, OptionRecommendation.HIGH),
        ("input_encoding", None, OptionRecommendation.HIGH),
        ("input_profile", "default", OptionRecommendation.HIGH),
        ("page_breaks_before", None, OptionRecommendation.HIGH),
        ("insert_metadata", False, OptionRecommendation.HIGH),
    }

    options = {
        OptionRecommendation(
            name="test",
            recommended_value=False,
            option_help=_(
                "Useful for recipe development. Forces"
                " max_articles_per_feed to 2 and downloads at most 2 feeds."
                " You can change the number of feeds and articles by supplying optional arguments."
                " For example: --test 3 1 will download at most 3 feeds and only 1 article per "
                "feed."
            ),
        ),
        OptionRecommendation(
            name="username",
            recommended_value=None,
            option_help=_("Username for sites that require a login to access content."),
        ),
        OptionRecommendation(
            name="password",
            recommended_value=None,
            option_help=_("Password for sites that require a login to access content."),
        ),
        OptionRecommendation(
            name="dont_download_recipe",
            recommended_value=False,
            option_help=_("Do not download latest version of builtin recipes from the calibre " "reader_server"),
        ),
        OptionRecommendation(
            name="lrf",
            recommended_value=False,
            option_help="Optimize fetching for subsequent conversion to LRF.",
        ),
    }

    def convert(self, recipe_or_file, options, file_ext, log, accelerators):
        """
        Download news from a site. Convert that news to an OEB for later conversion to another type of ebook.
        :param recipe_or_file: The recipe to download - either the name of an inbuilt recipe, a path to a .recipe file
                               or a zipped recipe extension
        :param options: Options to control the download
        :param file_ext: Control for what type of recipe it is.
                         If file_ext is 'downloaded_recipe' then the file is assumed to be a zipped recipe plugin.
                         (A zip file with a file in it, containing valid python, called 'download.recipe')
                         Otherwise will check to see if the passed recipe is a file - if it is them reads it and tries
                         to compile it.
                         Otherwise checks to see if the string is the name of an inbuilt plugin - if it is then loads it
                         and proceeds
        :param log:
        :param accelerators:
        :return:
        """

        from LiuXin.utils.web.feeds.recipes import compile_recipe

        options.output_profile.flow_size = 0
        recipe = None
        if file_ext == "downloaded_recipe":

            from LiuXin.utils.calibre_utils.calibre_zipfile import ZipFile

            zf = ZipFile(recipe_or_file, "r")
            zf.extractall()
            zf.close()
            self.recipe_source = open("download.recipe", "rb").read()
            recipe = compile_recipe(self.recipe_source)
            recipe.needs_subscription = False
            self.recipe_object = recipe(options, log, self.report_progress)

        else:

            if os.access(recipe_or_file, os.R_OK):
                with open(recipe_or_file, "rb") as r_or_f_pointer:
                    self.recipe_source = r_or_f_pointer.read()
                recipe = compile_recipe(self.recipe_source)
                log("Using custom recipe")
            else:
                from LiuXin.utils.web.feeds.recipes.collection import (
                    get_builtin_recipe_by_title,
                    get_builtin_recipe_titles,
                )

                title = getattr(options, "original_recipe_input_arg", recipe_or_file)
                title = os.path.basename(title).rpartition(".")[0]
                titles = frozenset(get_builtin_recipe_titles())
                if title not in titles:
                    title = getattr(options, "original_recipe_input_arg", recipe_or_file)
                    title = title.rpartition(".")[0]

                raw = get_builtin_recipe_by_title(title, log=log, download_recipe=not options.dont_download_recipe)
                builtin = False
                try:
                    recipe = compile_recipe(raw)
                    self.recipe_source = raw
                    if recipe.requires_version > numeric_version:
                        log.warn(
                            "Downloaded recipe needs calibre version at least: %s" % (".".join(recipe.requires_version))
                        )
                        builtin = True
                except Exception as e:
                    log.exception(
                        "Failed to compile downloaded recipe. Falling back to builtin one "
                        "- error message: {}".format(e.message)
                    )
                    builtin = True

                if builtin:
                    log("Using bundled builtin recipe")
                    raw = get_builtin_recipe_by_title(title, log=log, download_recipe=False)
                    if raw is None:
                        raise ValueError("Failed to find builtin recipe: " + title)
                    recipe = compile_recipe(raw)
                    self.recipe_source = raw
                else:
                    log("Using downloaded builtin recipe")

            if recipe is None:
                raise ValueError("%r is not a valid recipe file or builtin recipe" % recipe_or_file)

            disabled = getattr(recipe, "recipe_disabled", None)
            if disabled is not None:
                raise RecipeDisabled(disabled)
            ro = recipe(options, log, self.report_progress)
            ro.download()
            self.recipe_object = ro

        for key, val in self.recipe_object.conversion_options.items():
            setattr(options, key, val)

        for f in os.listdir("."):
            if f.endswith(".opf"):
                return os.path.abspath(f)

        for f in walk("."):
            if f.endswith(".opf"):
                return os.path.abspath(f)

    def postprocess_book(self, oeb, opts, log):
        if self.recipe_object is not None:
            self.recipe_object.postprocess_book(oeb, opts, log)

    def specialize(self, oeb, opts, log, output_fmt):
        if opts.no_inline_navbars:
            from LiuXin.file_formats.oeb.base import XPath

            for item in oeb.spine:
                for div in XPath('//h:div[contains(@class, "calibre_navbar")]')(item.data):
                    div.getparent().remove(div)

    def save_download(self, zf):
        raw = self.recipe_source
        if isinstance(raw, unicode):
            raw = raw.encode("utf-8")
        zf.writestr("download.recipe", raw)
