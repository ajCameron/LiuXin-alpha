#!/usr/bin/env python
# vim:fileencoding=UTF-8:ts=4:sw=4:sta:et:sts=4:ai

from __future__ import unicode_literals, division, absolute_import, print_function

__license__ = "GPL v3"
__copyright__ = "2012, Kovid Goyal <kovid@kovidgoyal.net>"
__docformat__ = "restructuredtext en"

# Conversion functions as follows
# 1) Convert input file to OEB (Open EBook) (input plugin)
# 2) Convert OEB to whatever format is desired (output plugin)
