
"""
Numpy based cache.
"""
