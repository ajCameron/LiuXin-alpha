# -*- coding: utf-8 -*-

import struct
import zlib

try:
    from PIL import Image

    # Image # May be needed to keep pyflakes happy.
except ImportError:
    import Image


from LiuXin.constants import __appname__, __version__

from LiuXin.file_formats.rb import HEADER
from LiuXin.file_formats.rb import unique_name
from LiuXin.file_formats.rb.rbml import RBMLizer

from LiuXin.utils.lx_libraries.liuxin_six import six_cStringIO

__license__ = "GPL 3"
__copyright__ = "2009, John Schember <john@nachtimwald.com>"
__docformat__ = "restructuredtext en"


TEXT_RECORD_SIZE = 4096


class TocItem(object):
    def __init__(self, name, size, flags):
        self.name = name
        self.size = size
        self.flags = flags


class RBWriter(object):
    def __init__(self, opts, log):
        self.opts = opts
        self.log = log
        self.name_map = {}

    def write_content(self, oeb_book, out_stream, metadata=None):
        info = [("info.info", self._info_section(metadata))]
        images = self._images(oeb_book.manifest)
        text_size, chuncks = self._text(oeb_book)
        chunck_sizes = [len(x) for x in chuncks]
        text = [("index.html", chuncks)]
        hidx = [("index.hidx", " ")]

        toc_items = []
        page_count = 0
        for name, data in info + text + hidx + images:
            page_count += 1
            size = len(data)
            if (name, data) in text:
                flags = 8
                size = 0
                for c in chunck_sizes:
                    size += c
                size += 8 + (len(chunck_sizes) * 4)
            elif (name, data) in info:
                flags = 2
            else:
                flags = 0
            toc_items.append(TocItem(name.ljust(32, "\x00")[:32], size, flags))

        self.log.debug("Writing file header...")
        out_stream.write(HEADER)
        out_stream.write(struct.pack("<I", 0))
        out_stream.write(struct.pack("<IH", 0, 0))
        out_stream.write(struct.pack("<I", 0x128))
        out_stream.write(struct.pack("<I", 0))

        for i in range(0x20, 0x128, 4):
            out_stream.write(struct.pack("<I", 0))

        out_stream.write(struct.pack("<I", page_count))
        offset = out_stream.tell() + (len(toc_items) * 44)

        for item in toc_items:
            out_stream.write(item.name)
            out_stream.write(struct.pack("<I", item.size))
            out_stream.write(struct.pack("<I", offset))
            out_stream.write(struct.pack("<I", item.flags))
            offset += item.size

        out_stream.write(info[0][1])

        self.log.debug("Writing compressed RB HTHML...")
        # Compressed text with proper heading
        out_stream.write(struct.pack("<I", len(text[0][1])))
        out_stream.write(struct.pack("<I", text_size))
        for size in chunck_sizes:
            out_stream.write(struct.pack("<I", size))
        for chunck in text[0][1]:
            out_stream.write(chunck)

        self.log.debug("Writing images...")
        for item in hidx + images:
            out_stream.write(item[1])

        total_size = out_stream.tell()
        out_stream.seek(0x1C)
        out_stream.write(struct.pack("<I", total_size))

    def _text(self, oeb_book):
        rbmlizer = RBMLizer(self.log, name_map=self.name_map)
        text = rbmlizer.extract_content(oeb_book, self.opts).encode("cp1252", "xmlcharrefreplace")
        size = len(text)

        pages = []
        for i in range(0, (len(text) + TEXT_RECORD_SIZE - 1) / TEXT_RECORD_SIZE):
            zobj = zlib.compressobj(9, zlib.DEFLATED, 13, 8, 0)
            pages.append(
                zobj.compress(text[i * TEXT_RECORD_SIZE : (i * TEXT_RECORD_SIZE) + TEXT_RECORD_SIZE]) + zobj.flush()
            )

        return size, pages

    def _images(self, manifest):
        from LiuXin.file_formats.oeb.base import OEB_RASTER_IMAGES

        images = []
        used_names = []

        for item in manifest:
            if item.media_type in OEB_RASTER_IMAGES:
                try:

                    im = Image.open(six_cStringIO(item.data)).convert("L")
                    data = six_cStringIO()
                    im.save(data, "PNG")
                    data = data.getvalue()

                    name = "%s.png" % len(used_names)
                    name = unique_name(name, used_names)
                    used_names.append(name)
                    self.name_map[item.href] = name

                    images.append((name, data))
                except Exception as e:
                    self.log.error("Error: Could not include file %s becuase %s." % (item.href, e))

        return images

    def _info_section(self, metadata):
        text = "TYPE=2\n"
        if metadata:
            if len(metadata.title) >= 1:
                text += "TITLE=%s\n" % metadata.title[0].value
            if len(metadata.creator) >= 1:
                from LiuXin.metadata import authors_to_string

                text += "AUTHOR=%s\n" % authors_to_string([x.value for x in metadata.creator])
        text += "GENERATOR=%s - %s\n" % (__appname__, __version__)
        text += "PARSE=1\n"
        text += "OUTPUT=1\n"
        text += "BODY=index.html\n"

        return text
